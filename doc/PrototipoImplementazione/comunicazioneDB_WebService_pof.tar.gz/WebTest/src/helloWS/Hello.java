package helloWS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.jws.WebMethod;
import javax.jws.WebService;
import org.hsqldb.*;

@WebService
public class Hello {
	
	@WebMethod
	public String say() throws SQLException { 

		new jdbcDriver();
		String url = "jdbc:hsqldb:file:/home/francesco/testdb", uname ="sa", pwd = null;
		Connection conn = DriverManager.getConnection(url,uname,pwd);
		return "it works: " + conn.toString();
		
	}

}
