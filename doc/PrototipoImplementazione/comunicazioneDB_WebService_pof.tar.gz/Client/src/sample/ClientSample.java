package sample;

import java.rmi.RemoteException;

import helloWS.*;

public class ClientSample {

	/**
	 * @param args
	 * @throws RemoteException 
	 */
	public static void main(String[] args) throws RemoteException {
		// TODO Auto-generated method stub
		System.out.println("* client works");
		System.out.println("* client connecting to server...");
		HelloProxy service = new HelloProxy();
		System.out.println("* webserver response: " + service.say());
		System.out.println("* done.");
	}

}
